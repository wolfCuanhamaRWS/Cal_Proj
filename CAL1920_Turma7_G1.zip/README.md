# Dependências
- API GraphViewer, fornecido nas aulas para visualização de grafos e as rotas pretendidas.
# Input files
Os ficheiros com informações relativas aos mapas do problema encontram-se na pasta MAPS_INSPECT_IT.
# Instruções de compilação
Para compilar o projeto é necessária uma instalação CLion.
Pronto para utilizar em UBUNTU, ou é necessários descomentar duas linhas de código para dar em windows.

**CLion:** Importar o projeto e executar com as ferramentas do programa.

